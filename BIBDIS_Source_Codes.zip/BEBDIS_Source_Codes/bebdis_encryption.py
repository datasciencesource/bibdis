#!/usr/bin/env python3
import subprocess
import os
import glob
import csv
import hashlib
import re
import sys

# -------------------------
# Helpers
# -------------------------
ishex64 = re.compile(r'^[0-9a-fA-F]{64}$').fullmatch


def run_silent(cmd: str, fail_msg: str):
    """Run a command quietly; print clean FAIL and exit on error."""
    print(f"\n$ {cmd}")
    try:
        subprocess.run(
            cmd,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=True
        )
    except subprocess.CalledProcessError:
        print(f"\n[FAIL] {fail_msg}")
        sys.exit(1)


def run_check(cmd: str, label_ok: str, label_fail: str, show_tail_lines: int = 12):
    """
    Run a command.
    - On success: print [OK]
    - On failure: print [FAIL] and show only last N stderr lines (no traceback)
    """
    print(f"\n$ {cmd}")
    try:
        subprocess.run(
            cmd,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            check=True
        )
        print(f"[OK] {label_ok}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n[FAIL] {label_fail}")
        err = ""
        if getattr(e, "stderr", None):
            err = e.stderr.decode(errors="ignore")
        err_lines = [ln.rstrip() for ln in err.splitlines() if ln.strip()]
        if err_lines:
            print("[DETAIL] Last error lines:")
            for ln in err_lines[-show_tail_lines:]:
                print("  " + ln)
        else:
            print("[DETAIL] No stderr output captured.")
        return False


def clean(pattern: str):
    for f in glob.glob(pattern):
        try:
            os.remove(f)
        except FileNotFoundError:
            pass


def hrow(fields, prev=None):
    s = "|".join(fields)
    if prev is not None:
        s += "|" + prev
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def parse_sqoop_line(line: str):
    """
    Sqoop part files are often delimited by Ctrl-A (\x01).
    Support both Ctrl-A and CSV.
    """
    line = line.rstrip("\n\r")
    if not line.strip():
        return None

    if "\x01" in line:
        return line.split("\x01")

    return next(csv.reader([line]))


def hash_file(src: str, dst: str, prev_hash):
    """
    Hash-chain a part file.
    - SKIP empty part files (normal in Hadoop splits)
    - Return (new_prev_hash, rows_hashed)
    """
    ph = prev_hash
    rows_hashed = 0
    tmp_dst = dst + ".tmp"

    with open(src, "r", encoding="utf-8", errors="ignore", newline="") as inf, \
         open(tmp_dst, "w", encoding="utf-8", newline="") as outf:
        w = csv.writer(outf)

        for line in inf:
            row = parse_sqoop_line(line)
            if not row or all(c.strip() == "" for c in row):
                continue

            # Strip existing hash if present (safe re-run)
            if ishex64(row[-1]):
                row = row[:-1]

            h = hrow(row, ph)
            w.writerow(row + [h])
            ph = h
            rows_hashed += 1

    if rows_hashed == 0:
        # Normal: empty partition file
        try:
            os.remove(tmp_dst)
        except FileNotFoundError:
            pass
        print(f"[WARN] {os.path.basename(src)} has 0 rows. Skipped.")
        return ph, 0

    os.replace(tmp_dst, dst)
    return ph, rows_hashed


def resolve_dataset_dir():
    """
    Your environment uses /dataset (seen in screenshots).
    Use it if present, otherwise create it.
    """
    if os.path.isdir("/dataset"):
        return "/dataset"
    os.makedirs("/dataset", exist_ok=True)
    return "/dataset"


def check_sqoop_credentials(connect: str, username: str, password: str):
    """
    Credential pre-check.
    If wrong credential -> clean FAIL + exit.
    """
    print("\n[CHECK] Verifying Sqoop credentials...")
    test_cmd = (
        "sqoop list-databases "
        f"--connect {connect} "
        f"--username {username} --password {password}"
    )

    ok = run_check(
        test_cmd,
        label_ok="Sqoop credentials are valid.",
        label_fail="Sqoop authentication failed (wrong credential or access denied).",
        show_tail_lines=8
    )
    if not ok:
        sys.exit(1)


def sqoop_import(import_cmd: str):
    """
    Sqoop import with short error tail on failure.
    """
    ok = run_check(
        import_cmd,
        label_ok="Sqoop imported successfully.",
        label_fail="Sqoop import failed.",
        show_tail_lines=15
    )
    if not ok:
        sys.exit(1)


# -------------------------
# Main workflow
# -------------------------
def main():
    dataset_dir = resolve_dataset_dir()

    # ====== Configuration (edit only if needed) ======
    connect = "jdbc:mysql://127.0.0.1/dbtest"
    username = "usertest"
    password = "Admin1111"
    table = "staff_data"

    # IMPORTANT: If HDFS permission fails using /staff_data,
    # change this to /user/<hdfs_user>/staff_data (e.g. /user/hduser/staff_data)
    hdfs_target_dir = "/staff_data"
    # ===============================================

    # (1) Start services / checks
    run_silent("/usr/local/hadoop/sbin/start-all.sh", "Hadoop services could not be started.")
    run_silent("jps", "Cannot verify Hadoop services (jps failed).")
    run_silent("sqoop version", "Sqoop is not available or 'sqoop version' failed.")

    # (2) Check HDFS is accessible (very important for Sqoop import)
    # If this fails, Sqoop import will fail.
    ok = run_check(
        "hadoop fs -ls /",
        label_ok="HDFS is accessible.",
        label_fail="HDFS is not accessible (NameNode/HDFS issue).",
        show_tail_lines=10
    )
    if not ok:
        sys.exit(1)

    # (3) Credential pre-check
    check_sqoop_credentials(connect, username, password)

    # (4) Sqoop import
    import_cmd = (
        "sqoop import "
        f"--connect {connect} "
        f"--username {username} --password {password} "
        f"--table {table} "
        f"--target-dir {hdfs_target_dir} "
        "--delete-target-dir"
    )
    sqoop_import(import_cmd)

    print("\n[OK] Import succeeded. Proceeding to extraction...")

    # (5) Extract from HDFS to local
    clean(f"{dataset_dir}/part-m-*")

    ok = run_check(
        f"hadoop fs -test -e {hdfs_target_dir}",
        label_ok=f"HDFS directory exists: {hdfs_target_dir}",
        label_fail=f"HDFS directory not found: {hdfs_target_dir}",
        show_tail_lines=8
    )
    if not ok:
        sys.exit(1)

    ok = run_check(
        f"hadoop fs -get {hdfs_target_dir}/part-m-* {dataset_dir}/",
        label_ok=f"Extracted part files to {dataset_dir}.",
        label_fail=f"Extraction failed: cannot get part files to {dataset_dir}.",
        show_tail_lines=12
    )
    if not ok:
        sys.exit(1)

    part_files = sorted(glob.glob(f"{dataset_dir}/part-m-*"))
    if not part_files:
        print(f"\n[FAIL] Extraction finished but no {dataset_dir}/part-m-* files were found.")
        sys.exit(1)

    print("\n[OK] Extraction succeeded. Proceeding to hash-chaining...")

    # (6) Hash-chain creation (skip empty part files)
    clean(f"{dataset_dir}/part-h-*")

    ph = None
    total_rows = 0
    hashed_files_created = 0

    for f in part_files:
        out = f.replace("part-m-", "part-h-")
        ph, rows = hash_file(f, out, ph)
        total_rows += rows
        if rows > 0:
            hashed_files_created += 1

    if total_rows == 0:
        print("\n[FAIL] All extracted part-m-* files are empty. Cannot build hash-chain.")
        sys.exit(1)

    hashed_files = sorted(glob.glob(f"{dataset_dir}/part-h-*"))
    if not hashed_files:
        print(f"\n[FAIL] Hash-chaining finished but no {dataset_dir}/part-h-* files were created.")
        sys.exit(1)

    print(f"\n[OK] Hashed files created : {hashed_files_created}")
    print(f"[OK] Total rows hashed   : {total_rows}")
    print(f"[OK] Raw data            : {dataset_dir}/part-m-*")
    print(f"[OK] Hashed data          : {dataset_dir}/part-h-*")
    print("[OK] Last hash           :", ph)


if __name__ == "__main__":
    main()
