#!/usr/bin/env python3
import glob, csv, hashlib, re, sys, os

ishex64 = re.compile(r'^[0-9a-fA-F]{64}$').fullmatch

def hrow(fields, prev=None):
    s = "|".join(fields)
    if prev:
        s += "|" + prev
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def validate_file(path, prev):
    ph = prev
    with open(path, newline="", encoding="utf-8") as inf:
        r = csv.reader(inf)
        rownum = 0
        for row in r:
            rownum += 1
            if not row or all(c.strip() == "" for c in row):
                continue

            # must end with 64-hex hash
            if not row[-1] or not ishex64(row[-1].strip()):
                print(f"\n[FAIL] Integrity validation FAILED.")
                print(f"[TAMPERED] {path} row {rownum}: missing/invalid hash column.")
                return None

            stored = row[-1].strip()
            data = row[:-1]
            expected = hrow(data, ph)

            if stored != expected:
                print(f"\n[FAIL] Integrity validation FAILED.")
                print(f"[TAMPERED] {path} row {rownum}: hash mismatch.")
                return None

            ph = stored

    print(f"[OK] VALID: {path}")
    return ph

def validate_all_parts_or_exit():
    files = sorted(glob.glob("/dataset/part-h-*"))
    if not files:
        print("\n[FAIL] No hashed files found: /dataset/part-h-*")
        print("[HINT] Run bebdis_encryption.py first to generate part-h-* files.")
        sys.exit(1)

    ph = None
    for f in files:
        ph = validate_file(f, ph)
        if ph is None:
            print("\n[STOP] Dataset is TAMPERED. Analysis will NOT execute.")
            sys.exit(1)

    print("\n[OK] Dataset integrity VERIFIED. Proceeding to analysis...")
    return True

def run_analysis_or_exit():
    file_list = sorted(glob.glob("/dataset/part-h-*"))
    if not file_list:
        print("\n[FAIL] Cannot analyze: missing /dataset/part-h-* files.")
        sys.exit(1)

    cleaned_data = []
    male = 0
    female = 0
    out_csv = "/dataset/staff_filtered.csv"

    for file_name in file_list:
        with open(file_name, "r", encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                if not row or all(c.strip() == "" for c in row):
                    continue

                # remove hash column
                if ishex64(row[-1].strip()):
                    data = row[:-1]
                else:
                    # should not happen after validation
                    print(f"\n[FAIL] Unexpected format in {file_name}: last column is not a hash.")
                    sys.exit(1)

                # select fields (same as your logic)
                if len(data) > 10:
                    selected = data[0:3] + [data[5], data[10]]
                    cleaned_data.append(selected)

    if not cleaned_data:
        print("\n[FAIL] Analysis cannot proceed: no rows matched the selection rules.")
        sys.exit(1)

    # write output
    with open(out_csv, "w", encoding="utf-8", newline="") as out:
        w = csv.writer(out)
        w.writerows(cleaned_data)

    # count male/female
    for row in cleaned_data:
        sex = row[3].strip().lower()
        if sex == "male":
            male += 1
        elif sex == "female":
            female += 1

    # confirm output exists
    if not os.path.exists(out_csv) or os.path.getsize(out_csv) == 0:
        print("\n[FAIL] Analysis output was not created correctly.")
        sys.exit(1)

    print(f"\n[OK] Analysis SUCCESS. Output written to: {out_csv}")
    print("[RESULT] Male  :", male)
    print("[RESULT] Female:", female)

def main():
    # (3) Validate integrity; if fail → exit with message
    validate_all_parts_or_exit()

    # (4) If can analyze show results; if cannot → exit with message
    run_analysis_or_exit()

if __name__ == "__main__":
    main()
